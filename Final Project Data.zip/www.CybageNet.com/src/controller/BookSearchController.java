package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.UserDao;
import pojos.Book;

/**
 * Servlet implementation class BookSearchController
 */
@WebServlet("/BookSearchController")
public class BookSearchController extends HttpServlet {
	
	private UserDao dao = new UserDao();
	
	private static final long serialVersionUID = 1L;
	
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookSearchController() {
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("BookSearch.jsp");
		
		//retrieving the users mode of book search
		String choice = request.getParameter("choice");
		
		//If User Chooses for category wise search
		if(choice != null && choice.equalsIgnoreCase("category"))
		{
			//adding list of all the categories to session scope
			session.setAttribute("categoryList", dao.getCategoryList());
			dispatcher.forward(request, response);
		}//id end
		else{
		
			String title = request.getParameter("title");
			String author = request.getParameter("author");
			String category = request.getParameter("categoryId");
			
			//Creating bookList
			List<Book> bookList = null;

			//Searching book by Title
			if(title != null){
				
				//populating bookList containing title as given title
				bookList = dao.getBooksByTitle(title);
				
				//adding show attribute to requestScope for Display purpose
				request.setAttribute("show", "show");
				
				//Checking for availability of required book
				if(!bookList.isEmpty())
					session.setAttribute("bookList", bookList);
				//Showing Error message that No Such record Exists
				else
					request.setAttribute("searchStatus", "No Record Found...");
				
				//forwarding to same jsp page
				dispatcher.forward(request, response);
			}//if end
			
			//Searching book by Author
			else if(author != null){
				//populating bookList containing required author
				bookList = dao.getBooksByAuthor(author);
				
				//Just for display purpose on jsp
				request.setAttribute("show", "show");
				
				//Checking for availability of required book
				if(!bookList.isEmpty())
					session.setAttribute("bookList", bookList);
				//showing error message
				else
					request.setAttribute("searchStatus", "No Record Found...");
				
				//forwarding to same jsp page
				dispatcher.forward(request, response);
			}//else-if end
			
			//Searching books by category
			else if(category != null){
				
				//populating bookList by selected Category
				bookList = dao.getBooksByCategory(Integer.parseInt(category));
				//for Display purpose
				request.setAttribute("show", "show");
				
				//checking availability of book
				if(!bookList.isEmpty())
					session.setAttribute("bookList", bookList);
				else
					request.setAttribute("searchStatus", "No Record Found...");
				
				//forwarding to same jsp page
				dispatcher.forward(request, response);
			}//else-if end
			else
				dispatcher.forward(request, response);
		}//else end
	}//doGet end

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
