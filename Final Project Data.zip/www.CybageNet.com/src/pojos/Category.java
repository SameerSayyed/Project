package pojos;

public class Category
{
	private int categoryId;
	private String cName;
	
	public Category() {
		
	}
	
	public Category(String cName) {
		super();
		this.cName = cName;
	}

	public Category(Integer categoryId, String cName) {
		super();
		this.categoryId = categoryId;
		this.cName = cName;
	}

	
	public int getCategoryId() 
	{
		return categoryId;
	}
	public void setCategoryId(int categoryId) 
	{
		this.categoryId = categoryId;
	}
	public String getcName() 
	{
		return cName;
	}
	public void setcName(String cName)
	{
		this.cName = cName;
	}
	@Override
	public String toString() {
		return "Category [categoryId=" + categoryId + ", cName=" + cName + "]";
	}
	
	
}
