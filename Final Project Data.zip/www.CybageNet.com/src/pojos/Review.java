package pojos;

public class Review {
	
	private Integer reviewId;
	private Book book;
	private User user;
	private String review;
	
	public Review() {
	}

	public Review(Book book, User user, String review) {
		super();
		this.book = book;
		this.user = user;
		this.review = review;
	}

	public Review(Integer reviewId, Book book, User user, String review) {
		super();
		this.reviewId = reviewId;
		this.book = book;
		this.user = user;
		this.review = review;
	}

	public Integer getReviewId() {
		return reviewId;
	}

	public void setReviewId(Integer reviewId) {
		this.reviewId = reviewId;
	}

	public Book getBook() {
		return book;
	}

	public void setBook(Book book) {
		this.book = book;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	@Override
	public String toString() {
		return "Review [reviewId=" + reviewId + ", book=" + book + ", user=" + user + ", review=" + review + "]";
	}
	
}
