package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import pojos.Book;
import pojos.Category;

public class AdminDao 
{
	Connection connection = DBManager.getConnection();
	
	public  List<Category> getCategories()
	{
		Statement statement = null;
		ResultSet resultSet = null;
		List<Category> categories = new ArrayList<>();
		try 
		{
			statement = connection.createStatement();
			resultSet = statement.executeQuery("select * from category");
			
			while(resultSet.next())
			{
				Category category = new Category();
				category.setCategoryId(resultSet.getInt(1));
				category.setcName(resultSet.getString(2));
				categories.add(category);
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return categories;
	}
	
	public int InsertBook(Book book)
	{
		
		PreparedStatement pstatement = null;
		int result = 0;
		
		try 
		{
			
			
			pstatement = connection.prepareStatement("insert into books(BTitle,BIsbn,BAuthor,CategoryId) values(?,?,?,?)");
			pstatement.setString(1, book.getbTitle());
			pstatement.setString(2, book.getbIsbn());
			pstatement.setString(3, book.getbAuthor());
			pstatement.setInt(4, book.getCategory().getCategoryId());
			
			result = pstatement.executeUpdate();
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
			return -1;
		}
		return result;
	}
	
	public int RemoveByTitle(String title)
	{
		int result = 0;
		PreparedStatement pstatement = null;
		
		try 
		{
			pstatement = connection.prepareStatement("delete from books where BTitle=?");
			pstatement.setString(1, title);
			result = pstatement.executeUpdate();
			
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		return result;
	}
	
	public int RemoveByIsbn(String isbn)
	{
		int result = 0;
		PreparedStatement pstatement = null;
		
		try 
		{
			pstatement = connection.prepareStatement("delete from books where BIsbn=?");
			pstatement.setString(1, isbn);
			result = pstatement.executeUpdate();
			
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		return result;
	}
}
